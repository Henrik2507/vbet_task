package Models;

public  class Variables
{
    //URLS
    public static final String Chrome="webdriver.chrome.driver";
    public static final String ChromePath="./Driver/chromedriver.exe";   // this Chrome version is 101.0.4896.127   // ete qo mot taza versionna kam hin
    //    https://chromedriver.chromium.org/downloads
    // download ara qo  chrome browseri version u edit ara Driver Folderi mechini het

}
